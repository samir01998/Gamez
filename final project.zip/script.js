function startGame() {
  alert("Gamez Loading... Bhidu 🎮");
}